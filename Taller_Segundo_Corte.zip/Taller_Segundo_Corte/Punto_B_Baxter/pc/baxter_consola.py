"""
baxter_consola.py  -  Punto B (real-to-sim)

Consola de mando con ESP32-S3 + joystick KY-023 para el robot Baxter en PyBullet.
Permite mover los dos brazos con cinematica inversa (IK), girar la muneca,
abrir/cerrar las pinzas para coger y mover un cubo, y reposicionar el robot.

Modos (se cambian con pulsacion CORTA del joystick, la ESP32 lleva la cuenta):
  0  BRAZO IZQ: plano XY        joystick = adelante/atras e izquierda/derecha
  1  BRAZO IZQ: altura Z/muneca  joystick Y = subir/bajar, X = girar muneca
  2  BRAZO DER: plano XY
  3  BRAZO DER: altura Z/muneca
  4  BASE: posicion del robot    joystick Y = avanzar/retroceder, X = girar
Pulsacion LARGA: abrir/cerrar la pinza del brazo activo
                 (en modo BASE: reinicia la escena)

Uso:
  python baxter_consola.py --puerto COM7
  python baxter_consola.py --sin-esp     (teclado: flechas, m = modo, espacio = accion)
"""

import argparse
import math
import os
import sys
import threading
import time

AQUI = os.path.dirname(os.path.abspath(__file__))

NOMBRES_MODOS = (
    "BRAZO IZQ: plano XY",
    "BRAZO IZQ: altura Z / muneca",
    "BRAZO DER: plano XY",
    "BRAZO DER: altura Z / muneca",
    "BASE: posicion del robot",
)

# Velocidades maximas (con el joystick al tope)
V_XY = 0.25        # m/s
V_Z = 0.18         # m/s
V_MUNECA = 1.2     # rad/s
V_BASE = 0.30      # m/s
V_GIRO = 0.60      # rad/s

# Limites del espacio de trabajo de cada pinza (marco del robot, metros)
LIM_X = (0.35, 1.05)
LIM_Z = (-0.28, 0.45)
LIM_Y = {"izq": (-0.10, 0.90), "der": (-0.90, 0.10)}
ALCANCE = 1.05     # distancia maxima hombro -> pinza

PISO_Z = -0.926    # altura del piso (la base de Baxter queda en z = 0)


# ---------------------------------------------------------------------------
# Lectura de la ESP32-S3 por USB (hilo aparte)
# ---------------------------------------------------------------------------
class LectorSerial(threading.Thread):
    def __init__(self, puerto, baud=115200):
        super().__init__(daemon=True)
        import serial
        self.serial = serial
        self.ser = serial.Serial(puerto, baud, timeout=0.1)
        self.lock = threading.Lock()
        self.dato = (0.0, 0.0, 0, 0)   # x, y, modo, acciones
        self.t = 0.0
        self.activo = True

    def run(self):
        while self.activo:
            try:
                linea = self.ser.readline().decode("utf-8", errors="ignore").strip()
            except Exception:
                if self.activo:
                    print("[PC] Se perdio la conexion con la ESP32-S3")
                break
            if linea.startswith("JOY,"):
                partes = linea.split(",")
                if len(partes) >= 5:
                    try:
                        d = (int(partes[1]) / 100.0, int(partes[2]) / 100.0,
                             int(partes[3]), int(partes[4]))
                    except ValueError:
                        continue
                    with self.lock:
                        self.dato = d
                        self.t = time.time()
            elif linea.startswith("INFO,"):
                print("[ESP32]", linea[5:])

    def leer(self):
        with self.lock:
            x, y, modo, acc = self.dato
            vivo = time.time() - self.t < 0.5
        if not vivo:            # sin senal: el robot se queda quieto
            x = y = 0.0
        return x, y, modo, acc, vivo

    def cerrar(self):
        self.activo = False
        try:
            self.ser.close()
        except Exception:
            pass


class TecladoComoJoystick:
    """Permite probar sin la ESP32: flechas, m = cambiar modo, espacio = accion."""
    def __init__(self, p, n_modos):
        self.p = p
        self.n = n_modos
        self.modo = 0
        self.acc = 0

    def leer(self):
        p = self.p
        t = p.getKeyboardEvents()
        x = y = 0.0
        if t.get(p.B3G_LEFT_ARROW, 0) & p.KEY_IS_DOWN:
            x -= 1
        if t.get(p.B3G_RIGHT_ARROW, 0) & p.KEY_IS_DOWN:
            x += 1
        if t.get(p.B3G_UP_ARROW, 0) & p.KEY_IS_DOWN:
            y += 1
        if t.get(p.B3G_DOWN_ARROW, 0) & p.KEY_IS_DOWN:
            y -= 1
        if t.get(ord("m"), 0) & p.KEY_WAS_TRIGGERED:
            self.modo = (self.modo + 1) % self.n
            print("[TECLADO] Modo:", NOMBRES_MODOS[self.modo])
        if t.get(ord(" "), 0) & p.KEY_WAS_TRIGGERED:
            self.acc += 1
        return x, y, self.modo, self.acc, True

    def cerrar(self):
        pass


def limitar(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


# ---------------------------------------------------------------------------
# Simulacion de Baxter
# ---------------------------------------------------------------------------
class SimBaxter:
    def __init__(self, p, ruta_datos, gui):
        import pybullet_data
        self.p = p
        self.gui = gui
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        if gui:
            p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 0)
            p.configureDebugVisualizer(p.COV_ENABLE_GUI, 0)
        p.setGravity(0, 0, -9.81)
        p.setPhysicsEngineParameter(numSolverIterations=100)

        self.piso = p.loadURDF("plane.urdf", [0, 0, PISO_Z], useFixedBase=True)

        urdf = os.path.join(ruta_datos, "baxter_common", "baxter_description", "urdf", "toms_baxter.urdf")
        if not os.path.isfile(urdf):
            sys.exit("[PC] No se encontro el modelo de Baxter en:\n  %s\n"
                     "Clona el repositorio pybullet_robots (ver README) o usa --datos." % urdf)
        self.robot = p.loadURDF(urdf, [0, 0, 0], useFixedBase=True,
                                flags=p.URDF_USE_SELF_COLLISION_EXCLUDE_ALL_PARENTS)

        # Indices de articulaciones y eslabones por nombre
        self.jid = {}
        self.lid = {}
        for i in range(p.getNumJoints(self.robot)):
            info = p.getJointInfo(self.robot, i)
            self.jid[info[1].decode()] = i
            self.lid[info[12].decode()] = i
        self.movibles = [i for i in range(p.getNumJoints(self.robot))
                         if p.getJointInfo(self.robot, i)[3] > -1]
        self.ll = [p.getJointInfo(self.robot, i)[8] for i in self.movibles]
        self.ul = [p.getJointInfo(self.robot, i)[9] for i in self.movibles]
        self.jr = [u - l for l, u in zip(self.ll, self.ul)]

        self.brazos = {
            "izq": {"ee": self.lid["left_gripper"],
                    "hombro": self.lid["left_upper_shoulder"],
                    "juntas": [self.jid[n] for n in ("left_s0", "left_s1", "left_e0", "left_e1",
                                                      "left_w0", "left_w1", "left_w2")],
                    "dedos": (self.jid["l_gripper_l_finger_joint"], self.jid["l_gripper_r_finger_joint"]),
                    "objetivo": [0.65, 0.35, 0.05], "muneca": 0.0,
                    "cerrada": False, "agarre": None, "obj": None},
            "der": {"ee": self.lid["right_gripper"],
                    "hombro": self.lid["right_upper_shoulder"],
                    "juntas": [self.jid[n] for n in ("right_s0", "right_s1", "right_e0", "right_e1",
                                                      "right_w0", "right_w1", "right_w2")],
                    "dedos": (self.jid["r_gripper_l_finger_joint"], self.jid["r_gripper_r_finger_joint"]),
                    "objetivo": [0.65, -0.35, 0.05], "muneca": 0.0,
                    "cerrada": False, "agarre": None, "obj": None},
        }
        self.base = [0.0, 0.0, 0.0]   # x, y, giro (yaw) del robot en el mundo

        # Mesa (girada 90 grados) y objetos
        self.mesa = p.loadURDF("table/table.urdf", [0.85, 0.0, PISO_Z],
                               p.getQuaternionFromEuler([0, 0, math.pi / 2]), useFixedBase=True)
        self.z_mesa = p.getAABB(self.mesa)[1][2]
        self.bandeja = p.loadURDF("tray/traybox.urdf", [0.72, -0.32, self.z_mesa],
                                  globalScaling=0.4, useFixedBase=True)
        self.objetos = []
        self.pos_ini_obj = [([0.68, 0.30, self.z_mesa + 0.025], [1, 0.3, 0.2, 1]),
                            ([0.80, 0.10, self.z_mesa + 0.025], [0.2, 0.5, 1, 1])]
        for pos, color in self.pos_ini_obj:
            o = p.loadURDF("cube_small.urdf", pos, globalScaling=0.8)
            p.changeVisualShape(o, -1, rgbaColor=color)
            p.changeDynamics(o, -1, lateralFriction=1.0)
            self.objetos.append(o)

        # Marcadores visuales de los objetivos de cada pinza
        self.marcas = {}
        for nombre, color in (("izq", [0, 1, 0, 0.6]), ("der", [1, 0.6, 0, 0.6])):
            forma = p.createVisualShape(p.GEOM_SPHERE, radius=0.025, rgbaColor=color)
            self.marcas[nombre] = p.createMultiBody(baseMass=0, baseVisualShapeIndex=forma,
                                                    basePosition=[0, 0, -5])
        self.hud = -1
        self.hud2 = -1

        # Postura inicial: brazos ya ubicados en sus objetivos
        for _ in range(4):
            for b in self.brazos.values():
                q = self._ik(b)
                for k, j in enumerate(self.movibles):
                    if j in b["juntas"]:
                        p.resetJointState(self.robot, j, q[k])
        for b in self.brazos.values():
            self._mover_dedos(b, abrir=True, instantaneo=True)

        if gui:
            p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 1)
            p.resetDebugVisualizerCamera(cameraDistance=2.4, cameraYaw=-145, cameraPitch=-28,
                                         cameraTargetPosition=[0.55, 0.0, -0.1])

    # ---------------- utilidades de marcos de referencia ----------------
    def robot_a_mundo(self, pos):
        x, y, z = pos
        bx, by, yaw = self.base
        c, s = math.cos(yaw), math.sin(yaw)
        return [bx + c * x - s * y, by + s * x + c * y, z]

    def _orientacion(self, b):
        # Pinza apuntando hacia abajo, girada segun la muneca y el giro del robot
        return self.p.getQuaternionFromEuler([0, math.pi, self.base[2] + b["muneca"]])

    def _ik(self, b):
        p = self.p
        actuales = [p.getJointState(self.robot, j)[0] for j in self.movibles]
        return p.calculateInverseKinematics(
            self.robot, b["ee"], self.robot_a_mundo(b["objetivo"]), self._orientacion(b),
            lowerLimits=self.ll, upperLimits=self.ul, jointRanges=self.jr, restPoses=actuales,
            maxNumIterations=60, residualThreshold=1e-4)

    # ---------------- comandos ----------------
    def mover_objetivo(self, lado, dx, dy, dz, dmuneca):
        b = self.brazos[lado]
        o = b["objetivo"]
        nuevo = [limitar(o[0] + dx, *LIM_X), limitar(o[1] + dy, *LIM_Y[lado]),
                 limitar(o[2] + dz, *LIM_Z)]
        # no dejar el objetivo fuera del alcance del brazo
        hombro_robot = [0.064, 0.259 if lado == "izq" else -0.259, 0.13]
        d = math.dist(nuevo, hombro_robot)
        if d > ALCANCE:
            nuevo = [hombro_robot[i] + (nuevo[i] - hombro_robot[i]) * ALCANCE / d for i in range(3)]
        b["objetivo"] = nuevo
        b["muneca"] = limitar(b["muneca"] + dmuneca, -math.pi, math.pi)

    def mover_base(self, avance, giro):
        bx, by, yaw = self.base
        bx += avance * math.cos(yaw)
        by += avance * math.sin(yaw)
        self.base = [limitar(bx, -1.5, 0.25), limitar(by, -1.5, 1.5), yaw + giro]
        self.p.resetBasePositionAndOrientation(
            self.robot, [self.base[0], self.base[1], 0],
            self.p.getQuaternionFromEuler([0, 0, self.base[2]]))

    def _mover_dedos(self, b, abrir, instantaneo=False):
        p = self.p
        jl, jr = b["dedos"]
        objetivo_l = 0.0208 if abrir else 0.0
        objetivo_r = -0.0208 if abrir else 0.0
        if instantaneo:
            p.resetJointState(self.robot, jl, objetivo_l)
            p.resetJointState(self.robot, jr, objetivo_r)
        p.setJointMotorControl2(self.robot, jl, p.POSITION_CONTROL, objetivo_l, force=20)
        p.setJointMotorControl2(self.robot, jr, p.POSITION_CONTROL, objetivo_r, force=20)

    def accion_pinza(self, lado):
        """Abre o cierra la pinza. Al cerrar cerca de un cubo, lo sujeta."""
        p = self.p
        b = self.brazos[lado]
        if b["cerrada"]:
            b["cerrada"] = False
            if b["agarre"] is not None:
                p.removeConstraint(b["agarre"])
                b["agarre"] = None
                b["obj"] = None
            self._mover_dedos(b, abrir=True)
            return "Pinza %s ABIERTA" % lado
        b["cerrada"] = True
        self._mover_dedos(b, abrir=False)
        ee = p.getLinkState(self.robot, b["ee"], computeForwardKinematics=True)
        mejor, dist_min = None, 0.06
        for o in self.objetos:
            if any(br["obj"] == o for br in self.brazos.values()):
                continue
            pos_o = p.getBasePositionAndOrientation(o)[0]
            d = math.dist(pos_o, ee[4])
            if d < dist_min:
                mejor, dist_min = o, d
        if mejor is None:
            return "Pinza %s CERRADA (sin objeto cerca)" % lado
        # Union fija pinza-cubo con la posicion relativa que tienen en este instante
        pos_o, orn_o = p.getBasePositionAndOrientation(mejor)
        inv_pos, inv_orn = p.invertTransform(ee[4], ee[5])
        rel_pos, rel_orn = p.multiplyTransforms(inv_pos, inv_orn, pos_o, orn_o)
        c = p.createConstraint(self.robot, b["ee"], mejor, -1, p.JOINT_FIXED, [0, 0, 0],
                               rel_pos, [0, 0, 0], rel_orn, [0, 0, 0, 1])
        p.changeConstraint(c, maxForce=60)
        b["agarre"] = c
        b["obj"] = mejor
        return "Pinza %s CERRADA: objeto agarrado" % lado

    def reiniciar_escena(self):
        p = self.p
        for b in self.brazos.values():
            if b["agarre"] is not None:
                p.removeConstraint(b["agarre"])
            b["agarre"], b["obj"], b["cerrada"] = None, None, False
            self._mover_dedos(b, abrir=True)
        for o, (pos, _) in zip(self.objetos, self.pos_ini_obj):
            p.resetBasePositionAndOrientation(o, pos, [0, 0, 0, 1])
            p.resetBaseVelocity(o, [0, 0, 0], [0, 0, 0])
        self.base = [0.0, 0.0, 0.0]
        self.mover_base(0, 0)
        return "Escena reiniciada"

    # ---------------- control de los motores ----------------
    def aplicar_ik(self):
        p = self.p
        for lado, b in self.brazos.items():
            q = self._ik(b)
            for k, j in enumerate(self.movibles):
                if j in b["juntas"]:
                    p.setJointMotorControl2(self.robot, j, p.POSITION_CONTROL, targetPosition=q[k],
                                            force=60 if j in b["juntas"][:4] else 20,
                                            maxVelocity=1.5)
            p.resetBasePositionAndOrientation(self.marcas[lado], self.robot_a_mundo(b["objetivo"]),
                                              [0, 0, 0, 1])

    def mostrar(self, modo, mensaje, vivo):
        if not self.gui:
            return
        p = self.p
        estado = "Modo %d: %s" % (modo, NOMBRES_MODOS[modo])
        if not vivo:
            estado = "SIN SENAL DE LA ESP32  |  " + estado
        pinzas = "Pinza izq: %s   Pinza der: %s   %s" % (
            "cerrada" if self.brazos["izq"]["cerrada"] else "abierta",
            "cerrada" if self.brazos["der"]["cerrada"] else "abierta", mensaje)
        cab = self.robot_a_mundo([0.0, 0.0, 1.15])
        self.hud = p.addUserDebugText(estado, cab, textColorRGB=[0.1, 0.1, 0.6], textSize=1.3,
                                      replaceItemUniqueId=self.hud)
        cab[2] -= 0.1
        self.hud2 = p.addUserDebugText(pinzas, cab, textColorRGB=[0.2, 0.2, 0.2], textSize=1.1,
                                       replaceItemUniqueId=self.hud2)

    def posicion_pinza(self, lado):
        return self.p.getLinkState(self.robot, self.brazos[lado]["ee"])[4]


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="Consola ESP32-S3 para Baxter")
    ap.add_argument("--puerto", default="COM7")
    ap.add_argument("--sin-esp", action="store_true")
    ap.add_argument("--datos", default=None, help="Carpeta data/ del repositorio pybullet_robots")
    ap.add_argument("--duracion", type=float, default=0)
    ap.add_argument("--sin-gui", action="store_true")
    args = ap.parse_args()

    import pybullet as p

    ruta = args.datos
    if ruta is None:
        for c in (os.path.join(AQUI, "pybullet_robots", "data"),
                  os.path.join(AQUI, "..", "pybullet_robots", "data"),
                  os.path.join(AQUI, "..", "..", "pybullet_robots", "data")):
            if os.path.isdir(c):
                ruta = c
                break
        else:
            ruta = os.path.join(AQUI, "pybullet_robots", "data")

    gui = not args.sin_gui
    p.connect(p.GUI if gui else p.DIRECT)
    sim = SimBaxter(p, ruta, gui)

    if args.sin_esp:
        entrada = TecladoComoJoystick(p, len(NOMBRES_MODOS))
    else:
        entrada = LectorSerial(args.puerto)
        entrada.start()
        print("[PC] Leyendo la consola ESP32-S3 en", args.puerto)

    DT_SIM = 1.0 / 240.0
    PASOS_CONTROL = 4                      # control a 60 Hz
    dt = DT_SIM * PASOS_CONTROL
    acc_prev = None
    mensaje = ""
    modo_prev = -1
    pasos = int(args.duracion / DT_SIM) if args.duracion > 0 else 10 ** 12
    t_ini = time.time()
    try:
        for i in range(pasos):
            if i % PASOS_CONTROL == 0:
                jx, jy, modo, acc, vivo = entrada.leer()
                modo = modo % len(NOMBRES_MODOS)
                if modo != modo_prev:
                    print("[PC] Modo:", NOMBRES_MODOS[modo])
                    modo_prev = modo
                if acc_prev is None:
                    acc_prev = acc
                if acc != acc_prev:                     # hubo pulsacion larga
                    acc_prev = acc
                    if modo in (0, 1):
                        mensaje = sim.accion_pinza("izq")
                    elif modo in (2, 3):
                        mensaje = sim.accion_pinza("der")
                    else:
                        mensaje = sim.reiniciar_escena()
                    print("[PC]", mensaje)

                lado = "izq" if modo in (0, 1) else "der"
                if modo in (0, 2):        # plano XY: arriba = alejarse del robot
                    sim.mover_objetivo(lado, jy * V_XY * dt, -jx * V_XY * dt, 0, 0)
                elif modo in (1, 3):      # altura y muneca
                    sim.mover_objetivo(lado, 0, 0, jy * V_Z * dt, -jx * V_MUNECA * dt)
                else:                     # base del robot
                    if jx or jy:
                        sim.mover_base(jy * V_BASE * dt, -jx * V_GIRO * dt)
                sim.aplicar_ik()
                if i % (PASOS_CONTROL * 6) == 0:
                    sim.mostrar(modo, mensaje, vivo)
                if not gui and i % 240 == 0:
                    print("t=%5.1f modo=%d izq=%s der=%s cubos=%s" % (
                        i * DT_SIM, modo,
                        [round(v, 2) for v in sim.posicion_pinza("izq")],
                        [round(v, 2) for v in sim.posicion_pinza("der")],
                        [[round(v, 2) for v in p.getBasePositionAndOrientation(o)[0]] for o in sim.objetos]))
            p.stepSimulation()
            # tiempo real
            atraso = (i + 1) * DT_SIM - (time.time() - t_ini)
            if atraso > 0:
                time.sleep(atraso)
    except KeyboardInterrupt:
        pass
    finally:
        entrada.cerrar()
        p.disconnect()


if __name__ == "__main__":
    main()
