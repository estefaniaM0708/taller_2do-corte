# main.py  -  ESP32-S3 (MicroPython)
# Punto B: consola de mando para el robot Baxter en PyBullet.
#
# Hardware: joystick analogico KY-023
#   VRx -> GPIO1   VRy -> GPIO2   SW -> GPIO4   +5V -> 3V3   GND -> GND
#
# La ESP32-S3 lee el joystick, filtra la senal, maneja los modos de la consola
# y envia por USB al PC 50 tramas por segundo:
#   JOY,<x>,<y>,<modo>,<acciones>
#     x, y      : joystick en porcentaje (-100 a 100), ya filtrado y con zona muerta
#     modo      : modo actual de la consola (0 a N_MODOS-1)
#     acciones  : contador de pulsaciones largas (el PC detecta cuando aumenta)
#
# Controles:
#   - Pulsacion CORTA: cambia de modo
#   - Pulsacion LARGA (>0.7 s): accion del modo (abrir / cerrar la pinza)

import sys
import time
from machine import Pin, ADC

# ---------------- configuracion ----------------
PIN_VRX = 1
PIN_VRY = 2
PIN_SW = 4

INVERTIR_X = False
INVERTIR_Y = True
INTERCAMBIAR_XY = False

MODOS = (
    "BRAZO IZQ: plano XY",
    "BRAZO IZQ: altura Z / muneca",
    "BRAZO DER: plano XY",
    "BRAZO DER: altura Z / muneca",
    "BASE: posicion del robot",
)

PERIODO_MS = 20          # 50 Hz
PRESION_LARGA_MS = 700
ZONA_MUERTA = 0.12
FILTRO = 0.35


class Joystick:
    def __init__(self, pin_x, pin_y):
        self.ax = ADC(Pin(pin_x))
        self.ay = ADC(Pin(pin_y))
        self.ax.atten(ADC.ATTN_11DB)
        self.ay.atten(ADC.ATTN_11DB)
        self.fx = 0.0
        self.fy = 0.0
        self.calibrar()

    def calibrar(self, n=64):
        sx = sy = 0
        for _ in range(n):
            sx += self.ax.read_u16()
            sy += self.ay.read_u16()
            time.sleep_ms(2)
        self.cx = sx / n
        self.cy = sy / n

    @staticmethod
    def _normalizar(v, c):
        r = (v - c) / (65535 - c) if v >= c else (v - c) / c
        r = max(-1.0, min(1.0, r))
        if abs(r) < ZONA_MUERTA:
            return 0.0
        signo = 1.0 if r > 0 else -1.0
        r = (abs(r) - ZONA_MUERTA) / (1.0 - ZONA_MUERTA)
        return signo * (0.4 * r + 0.6 * r * r * r)

    def leer(self):
        nx = self._normalizar(self.ax.read_u16(), self.cx)
        ny = self._normalizar(self.ay.read_u16(), self.cy)
        if INTERCAMBIAR_XY:
            nx, ny = ny, nx
        if INVERTIR_X:
            nx = -nx
        if INVERTIR_Y:
            ny = -ny
        self.fx += FILTRO * (nx - self.fx)
        self.fy += FILTRO * (ny - self.fy)
        if abs(self.fx) < 0.01:
            self.fx = 0.0
        if abs(self.fy) < 0.01:
            self.fy = 0.0
        return self.fx, self.fy


class Boton:
    def __init__(self, pin):
        self.p = Pin(pin, Pin.IN, Pin.PULL_UP)
        self.antes = False
        self.t0 = 0
        self.larga_hecha = False

    def evento(self):
        ahora = time.ticks_ms()
        presionado = self.p.value() == 0
        ev = None
        if presionado and not self.antes:
            self.t0 = ahora
            self.larga_hecha = False
        elif presionado and not self.larga_hecha:
            if time.ticks_diff(ahora, self.t0) >= PRESION_LARGA_MS:
                self.larga_hecha = True
                ev = "LARGA"
        elif not presionado and self.antes:
            if not self.larga_hecha and time.ticks_diff(ahora, self.t0) > 30:
                ev = "CORTA"
        self.antes = presionado
        return ev


def main():
    joy = Joystick(PIN_VRX, PIN_VRY)
    boton = Boton(PIN_SW)
    modo = 0
    acciones = 0
    sys.stdout.write("INFO,Consola Baxter lista. Modo: %s\n" % MODOS[modo])

    while True:
        t_ini = time.ticks_ms()

        ev = boton.evento()
        if ev == "CORTA":
            modo = (modo + 1) % len(MODOS)
            sys.stdout.write("INFO,Modo: %s\n" % MODOS[modo])
        elif ev == "LARGA":
            acciones += 1

        jx, jy = joy.leer()
        sys.stdout.write("JOY,%d,%d,%d,%d\n" % (int(jx * 100), int(jy * 100), modo, acciones))

        espera = PERIODO_MS - time.ticks_diff(time.ticks_ms(), t_ini)
        if espera > 0:
            time.sleep_ms(espera)


main()
