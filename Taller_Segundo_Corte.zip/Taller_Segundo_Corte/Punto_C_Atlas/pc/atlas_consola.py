"""
atlas_consola.py  -  Punto C (real-to-sim)

Consola de mando con ESP32-S3 + joystick KY-023 para el humanoide Atlas
(Boston Dynamics) dentro del laboratorio "botlab" de PyBullet, como en la
imagen del taller. El robot puede caminar (con marcha animada y seguimiento
del piso), mover cada brazo, girar el torso y la cabeza, agacharse,
inclinarse y hacer gestos. La camara de su cabeza se muestra en los paneles
RGB, profundidad y segmentacion de PyBullet.

Modos (pulsacion CORTA del joystick; la ESP32 lleva la cuenta):
  0  CAMINAR                Y = avanzar/retroceder, X = girar
  1  BRAZO DER: hombro      Y = subir/bajar brazo,  X = adelante/atras
  2  BRAZO DER: codo        Y = doblar codo,        X = girar brazo
  3  BRAZO IZQ: hombro
  4  BRAZO IZQ: codo
  5  TORSO Y CABEZA         X = girar torso,        Y = mover cabeza
  6  AGACHARSE / INCLINARSE Y = agacharse/pararse,  X = inclinarse a un lado
Pulsacion LARGA: siguiente gesto (reposo, saludo, brazos arriba, pose T)

Uso:
  python atlas_consola.py --puerto COM7
  python atlas_consola.py --sin-esp            (teclado: flechas, m = modo, espacio = gesto)
  python atlas_consola.py --escena simple      (piso liso, para PCs lentos)
"""

import argparse
import math
import os
import sys
import threading
import time

AQUI = os.path.dirname(os.path.abspath(__file__))

NOMBRES_MODOS = (
    "CAMINAR: avanzar / girar",
    "BRAZO DER: hombro",
    "BRAZO DER: codo",
    "BRAZO IZQ: hombro",
    "BRAZO IZQ: codo",
    "TORSO Y CABEZA",
    "AGACHARSE / INCLINARSE",
)
GESTOS = ("REPOSO", "SALUDO", "BRAZOS ARRIBA", "POSE T")

V_CAMINAR = 0.6     # m/s
V_GIRO = 0.9        # rad/s
V_JUNTA = 1.4       # rad/s para brazos, torso y cabeza
V_AGACHAR = 0.8     # fraccion por segundo
ESCALON_MAX = 0.20  # desnivel maximo que puede subir (m)

# Dimensiones de la pierna de Atlas (del URDF)
CADERA = 0.066      # pelvis -> articulacion de la cadera (m)
MUSLO = 0.374
CANILLA = 0.422
PIE = 0.075         # tobillo -> suela


# ---------------------------------------------------------------------------
# Entrada: ESP32-S3 por USB o teclado
# ---------------------------------------------------------------------------
class LectorSerial(threading.Thread):
    def __init__(self, puerto, baud=115200):
        super().__init__(daemon=True)
        import serial
        self.ser = serial.Serial(puerto, baud, timeout=0.1)
        self.lock = threading.Lock()
        self.dato = (0.0, 0.0, 0, 0)
        self.t = 0.0
        self.activo = True

    def run(self):
        while self.activo:
            try:
                linea = self.ser.readline().decode("utf-8", errors="ignore").strip()
            except Exception:
                if self.activo:
                    print("[PC] Se perdio la conexion con la ESP32-S3")
                break
            if linea.startswith("JOY,"):
                partes = linea.split(",")
                if len(partes) >= 5:
                    try:
                        d = (int(partes[1]) / 100.0, int(partes[2]) / 100.0,
                             int(partes[3]), int(partes[4]))
                    except ValueError:
                        continue
                    with self.lock:
                        self.dato = d
                        self.t = time.time()
            elif linea.startswith("INFO,"):
                print("[ESP32]", linea[5:])

    def leer(self):
        with self.lock:
            x, y, modo, acc = self.dato
            vivo = time.time() - self.t < 0.5
        if not vivo:
            x = y = 0.0
        return x, y, modo, acc, vivo

    def cerrar(self):
        self.activo = False
        try:
            self.ser.close()
        except Exception:
            pass


class TecladoComoJoystick:
    def __init__(self, p, n_modos):
        self.p = p
        self.n = n_modos
        self.modo = 0
        self.acc = 0

    def leer(self):
        p = self.p
        t = p.getKeyboardEvents()
        x = y = 0.0
        if t.get(p.B3G_LEFT_ARROW, 0) & p.KEY_IS_DOWN:
            x -= 1
        if t.get(p.B3G_RIGHT_ARROW, 0) & p.KEY_IS_DOWN:
            x += 1
        if t.get(p.B3G_UP_ARROW, 0) & p.KEY_IS_DOWN:
            y += 1
        if t.get(p.B3G_DOWN_ARROW, 0) & p.KEY_IS_DOWN:
            y -= 1
        if t.get(ord("m"), 0) & p.KEY_WAS_TRIGGERED:
            self.modo = (self.modo + 1) % self.n
        if t.get(ord(" "), 0) & p.KEY_WAS_TRIGGERED:
            self.acc += 1
        return x, y, self.modo, self.acc, True

    def cerrar(self):
        pass


def limitar(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


# ---------------------------------------------------------------------------
# Simulacion de Atlas
# ---------------------------------------------------------------------------
class SimAtlas:
    def __init__(self, p, ruta_datos, escena, gui):
        import pybullet_data
        self.p = p
        self.gui = gui
        p.setAdditionalSearchPath(pybullet_data.getDataPath())
        if gui:
            p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 0)
        p.setGravity(0, 0, -9.81)

        urdf_atlas = os.path.join(ruta_datos, "atlas", "atlas_v4_with_multisense.urdf")
        if not os.path.isfile(urdf_atlas):
            sys.exit("[PC] No se encontro el modelo de Atlas en:\n  %s\n"
                     "Clona el repositorio pybullet_robots (ver README) o usa --datos." % urdf_atlas)

        # ---- escenario ----
        if escena == "botlab":
            objs = p.loadSDF(os.path.join(ruta_datos, "botlab", "botlab.sdf"), globalScaling=2.0)
            y_a_z = p.getQuaternionFromEuler([math.pi / 2, 0, math.pi / 2])
            for o in objs:   # el modelo viene con el eje Y hacia arriba: se gira
                pos, orn = p.getBasePositionAndOrientation(o)
                pos, orn = p.multiplyTransforms([0, 0, 0], y_a_z, pos, orn)
                p.resetBasePositionAndOrientation(o, pos, orn)
            p.loadURDF(os.path.join(ruta_datos, "boston_box.urdf"), [-2, 3, -2], useFixedBase=True)
            p.loadURDF(os.path.join(ruta_datos, "boston_box.urdf"), [0, 3, -2], useFixedBase=True)
            inicio = [-2.0, 3.0]
            altura_rayo = -0.6       # por debajo de las lamparas del techo
        else:
            p.loadURDF("plane.urdf", [0, 0, 0], useFixedBase=True)
            p.loadURDF(os.path.join(ruta_datos, "boston_box.urdf"), [2.5, 0, -0.25], useFixedBase=True)
            for i, (x, y) in enumerate(((1.5, 1.5), (1.8, -1.2), (-1.5, 1.0))):
                c = p.loadURDF("cube.urdf", [x, y, 0.25], globalScaling=0.5)
                p.changeVisualShape(c, -1, rgbaColor=[[1, .3, .2, 1], [.2, .6, 1, 1], [1, .8, .1, 1]][i])
            inicio = [0.0, 0.0]
            altura_rayo = 2.0

        # ---- robot (base fija: la pelvis se ubica en cada paso) ----
        self.robot = p.loadURDF(urdf_atlas, [inicio[0], inicio[1], 5], useFixedBase=True)
        self.j = {}
        self.l = {}
        for i in range(p.getNumJoints(self.robot)):
            info = p.getJointInfo(self.robot, i)
            self.j[info[1].decode()] = (i, info[8], info[9], info[10])   # indice, min, max, fuerza
            self.l[info[12].decode()] = i
        # La pelvis se ubica por software (cinematica): las piernas no deben
        # chocar con el piso, si no la fisica las empujaria y temblarian.
        for nombre, idx in list(self.l.items()) + [("pelvis", -1)]:
            if "leg" in nombre or "foot" in nombre or "glut" in nombre or "talus" in nombre or nombre == "pelvis":
                p.setCollisionFilterGroupMask(self.robot, idx, 0, 0)

        self.x, self.y, self.yaw = inicio[0], inicio[1], 0.0
        self.piso = self._altura_piso(self.x, self.y, altura_rayo)
        self.z = self.piso + 0.937
        self.v = 0.0
        self.w = 0.0
        self.fase = 0.0
        self.amp = 0.0
        self.bloqueado = False

        # estado "abstracto" de la consola (no son angulos crudos)
        self.brazo = {"izq": {"elev": -1.25, "adel": 0.1, "codo": 0.35, "giro": 0.4},
                      "der": {"elev": -1.25, "adel": 0.1, "codo": 0.35, "giro": 0.4}}
        self.torso_giro = 0.0
        self.cabeza = 0.0
        self.inclinacion = 0.0
        self.agachar = 0.0
        self.gesto = 0
        self.t_saludo = -1.0

        self.objetivos = {}
        self._calcular_objetivos(0.0)
        for nombre, valor in self.objetivos.items():
            p.resetJointState(self.robot, self.j[nombre][0], valor)
        self._ubicar_pelvis(1.0)

        self.hud = -1
        self.t_cam = 0
        if gui:
            p.configureDebugVisualizer(p.COV_ENABLE_RENDERING, 1)
            p.configureDebugVisualizer(p.COV_ENABLE_RGB_BUFFER_PREVIEW, 1)
            p.configureDebugVisualizer(p.COV_ENABLE_DEPTH_BUFFER_PREVIEW, 1)
            p.configureDebugVisualizer(p.COV_ENABLE_SEGMENTATION_MARK_PREVIEW, 1)
            p.resetDebugVisualizerCamera(cameraDistance=3.2, cameraYaw=148, cameraPitch=-12,
                                         cameraTargetPosition=[self.x, self.y, self.z - 0.2])

    # ---------------- piso bajo el robot ----------------
    def _altura_piso(self, x, y, desde):
        # Rayo vertical bajo la pelvis (las piernas y la pelvis no chocan con rayos)
        r = self.p.rayTest([x, y, desde], [x, y, desde - 20])[0]
        if r[0] == self.robot:
            r = self.p.rayTest([x, y, r[3][2] - 0.01], [x, y, desde - 20])[0]
        return r[3][2] if r[0] >= 0 else self.piso

    # ---------------- comandos de la consola ----------------
    def mover_brazo(self, lado, d_elev=0.0, d_adel=0.0, d_codo=0.0, d_giro=0.0):
        b = self.brazo[lado]
        b["elev"] = limitar(b["elev"] + d_elev, -1.4, 1.5)
        b["adel"] = limitar(b["adel"] + d_adel, -0.78, 1.5)
        b["codo"] = limitar(b["codo"] + d_codo, 0.0, 2.3)
        b["giro"] = limitar(b["giro"] + d_giro, 0.0, 3.1)
        self.t_saludo = -1.0

    def mover_torso(self, d_giro, d_cabeza):
        self.torso_giro = limitar(self.torso_giro + d_giro, -0.65, 0.65)
        self.cabeza = limitar(self.cabeza + d_cabeza, -0.6, 1.1)

    def mover_postura(self, d_agachar, d_incl):
        self.agachar = limitar(self.agachar + d_agachar, 0.0, 1.0)
        self.inclinacion = limitar(self.inclinacion + d_incl, -0.45, 0.45)

    def siguiente_gesto(self):
        self.gesto = (self.gesto + 1) % len(GESTOS)
        nombre = GESTOS[self.gesto]
        reposo = {"elev": -1.25, "adel": 0.1, "codo": 0.35, "giro": 0.4}
        if nombre == "REPOSO":
            self.brazo = {"izq": dict(reposo), "der": dict(reposo)}
        elif nombre == "SALUDO":
            self.brazo["izq"] = dict(reposo)
            self.brazo["der"] = {"elev": 0.25, "adel": 0.3, "codo": 1.3, "giro": 1.6}
            self.t_saludo = 0.0
        elif nombre == "BRAZOS ARRIBA":
            arriba = {"elev": 1.45, "adel": 0.2, "codo": 0.1, "giro": 0.3}
            self.brazo = {"izq": dict(arriba), "der": dict(arriba)}
        else:  # POSE T
            t = {"elev": 0.0, "adel": 0.0, "codo": 0.0, "giro": 0.0}
            self.brazo = {"izq": dict(t), "der": dict(t)}
        return nombre

    def caminar(self, avance, giro, dt):
        # velocidad suavizada (arranca y frena sin saltos)
        k = min(1.0, 4.0 * dt)
        self.v += (avance * V_CAMINAR - self.v) * k
        self.w += (giro * V_GIRO - self.w) * k
        self.yaw += self.w * dt
        nx = self.x + self.v * math.cos(self.yaw) * dt
        ny = self.y + self.v * math.sin(self.yaw) * dt
        piso_nuevo = self._altura_piso(nx, ny, self.z - 0.1)
        if piso_nuevo - self.piso > ESCALON_MAX:   # pared u obstaculo alto
            self.bloqueado = True
            self.v = 0.0
        else:
            self.bloqueado = False
            self.x, self.y, self.piso = nx, ny, piso_nuevo
        # la marcha: frecuencia y amplitud segun la velocidad
        intensidad = min(1.0, (abs(self.v) + 0.4 * abs(self.w)) / 0.3)
        self.amp += (intensidad - self.amp) * k
        self.fase += 2 * math.pi * (0.4 + abs(self.v) / 0.9) * dt * (1 if self.amp > 0.02 else 0)

    # ---------------- angulos de las articulaciones ----------------
    def _calcular_objetivos(self, dt):
        o = {}
        a = self.agachar
        signo = 1.0 if self.v >= 0 else -1.0
        for lado, desfase in (("l", 0.0), ("r", math.pi)):
            f = self.fase + desfase
            hpy = -0.9 * a - signo * 0.38 * self.amp * math.sin(f)
            kny = 1.6 * a + 0.12 * self.amp + 0.75 * self.amp * max(0.0, math.cos(f))
            o[lado + "_leg_hpy"] = hpy
            o[lado + "_leg_kny"] = kny
            o[lado + "_leg_aky"] = -(hpy + kny)        # pie paralelo al piso
            o[lado + "_leg_hpx"] = 0.0
            o[lado + "_leg_akx"] = 0.0
            o[lado + "_leg_hpz"] = 0.0

        # saludo animado (mueve el antebrazo de lado a lado durante 4 s)
        der = dict(self.brazo["der"])
        if 0.0 <= self.t_saludo < 4.0:
            self.t_saludo += dt
            der["codo"] = 1.3 + 0.45 * math.sin(self.t_saludo * 9.0)

        balanceo = 0.35 * self.amp * math.sin(self.fase)    # brazos al caminar
        for lado, b, s, bal in (("l", self.brazo["izq"], 1.0, balanceo),
                                ("r", der, -1.0, -balanceo)):
            o[lado + "_arm_shx"] = s * b["elev"]
            o[lado + "_arm_shz"] = -s * (b["adel"] + bal)
            o[lado + "_arm_elx"] = s * b["codo"]
            o[lado + "_arm_ely"] = b["giro"]
            o[lado + "_arm_wrx"] = 0.0
            o[lado + "_arm_wry"] = 0.0
        o["back_bkz"] = self.torso_giro
        o["back_bkx"] = self.inclinacion
        o["back_bky"] = 0.25 * a                         # se inclina al agacharse
        o["neck_ry"] = self.cabeza
        # recortar a los limites del URDF
        for n in o:
            _, lo, hi, _ = self.j[n]
            o[n] = limitar(o[n], lo, hi)
        self.objetivos = o

    def _caida_pierna(self, lado):
        hpy = self.objetivos[lado + "_leg_hpy"]
        kny = self.objetivos[lado + "_leg_kny"]
        return CADERA + MUSLO * math.cos(hpy) + CANILLA * math.cos(hpy + kny) + PIE

    def _ubicar_pelvis(self, dt):
        # altura para que el pie mas bajo toque el piso; bajar/subir escalones suave
        z_obj = self.piso + max(self._caida_pierna("l"), self._caida_pierna("r"))
        dz = z_obj - self.z
        self.z += limitar(dz, -2.5 * dt, 1.2 * dt)
        self.p.resetBasePositionAndOrientation(
            self.robot, [self.x, self.y, self.z], self.p.getQuaternionFromEuler([0, 0, self.yaw]))

    def actualizar(self, dt):
        p = self.p
        self._calcular_objetivos(dt)
        for nombre, valor in self.objetivos.items():
            idx, _, _, fuerza = self.j[nombre]
            p.setJointMotorControl2(self.robot, idx, p.POSITION_CONTROL, targetPosition=valor,
                                    force=fuerza, maxVelocity=4.0 if "_leg_" in nombre else 2.5)
        self._ubicar_pelvis(dt)

    # ---------------- vistas ----------------
    def camara_cabeza(self):
        """Imagen desde la cabeza de Atlas: aparece en los paneles RGB/Depth/Segmentation."""
        p = self.p
        st = p.getLinkState(self.robot, self.l["head"])
        pos, orn = st[4], st[5]
        m = p.getMatrixFromQuaternion(orn)
        adelante = [m[0], m[3], m[6]]
        arriba = [m[2], m[5], m[8]]
        ojo = [pos[i] + 0.12 * adelante[i] + 0.05 * arriba[i] for i in range(3)]
        mira = [ojo[i] + 2.0 * adelante[i] for i in range(3)]
        vista = p.computeViewMatrix(ojo, mira, arriba)
        proy = p.computeProjectionMatrixFOV(75, 4 / 3, 0.05, 15)
        p.getCameraImage(192, 144, vista, proy, renderer=p.ER_BULLET_HARDWARE_OPENGL)

    def seguir_con_camara(self):
        p = self.p
        cam = p.getDebugVisualizerCamera()
        p.resetDebugVisualizerCamera(cam[10], cam[8], cam[9], [self.x, self.y, self.z - 0.2])

    def mostrar(self, modo, vivo, mensaje):
        if not self.gui:
            return
        txt = "Modo %d: %s | Gesto: %s" % (modo, NOMBRES_MODOS[modo], GESTOS[self.gesto])
        if self.bloqueado:
            txt += " | OBSTACULO"
        if not vivo:
            txt = "SIN SENAL DE LA ESP32 | " + txt
        if mensaje:
            txt += " | " + mensaje
        self.hud = self.p.addUserDebugText(txt, [self.x, self.y, self.z + 1.15],
                                           textColorRGB=[0.1, 0.1, 0.5], textSize=1.2,
                                           replaceItemUniqueId=self.hud)


# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="Consola ESP32-S3 para Atlas")
    ap.add_argument("--puerto", default="COM7")
    ap.add_argument("--sin-esp", action="store_true")
    ap.add_argument("--datos", default=None, help="Carpeta data/ del repositorio pybullet_robots")
    ap.add_argument("--escena", choices=("botlab", "simple"), default="botlab")
    ap.add_argument("--duracion", type=float, default=0)
    ap.add_argument("--sin-gui", action="store_true")
    args = ap.parse_args()

    import pybullet as p

    ruta = args.datos
    if ruta is None:
        for c in (os.path.join(AQUI, "pybullet_robots", "data"),
                  os.path.join(AQUI, "..", "pybullet_robots", "data"),
                  os.path.join(AQUI, "..", "..", "pybullet_robots", "data")):
            if os.path.isdir(c):
                ruta = c
                break
        else:
            ruta = os.path.join(AQUI, "pybullet_robots", "data")

    gui = not args.sin_gui
    p.connect(p.GUI if gui else p.DIRECT)
    sim = SimAtlas(p, ruta, args.escena, gui)

    if args.sin_esp:
        entrada = TecladoComoJoystick(p, len(NOMBRES_MODOS))
    else:
        entrada = LectorSerial(args.puerto)
        entrada.start()
        print("[PC] Leyendo la consola ESP32-S3 en", args.puerto)

    DT_SIM = 1.0 / 240.0
    PASOS_CONTROL = 4
    dt = DT_SIM * PASOS_CONTROL
    acc_prev = None
    modo_prev = -1
    mensaje = ""
    pasos = int(args.duracion / DT_SIM) if args.duracion > 0 else 10 ** 12
    t_ini = time.time()
    try:
        for i in range(pasos):
            if i % PASOS_CONTROL == 0:
                k = i // PASOS_CONTROL
                jx, jy, modo, acc, vivo = entrada.leer()
                modo = modo % len(NOMBRES_MODOS)
                if modo != modo_prev:
                    print("[PC] Modo:", NOMBRES_MODOS[modo])
                    modo_prev = modo
                if acc_prev is None:
                    acc_prev = acc
                if acc != acc_prev:
                    acc_prev = acc
                    mensaje = "Gesto: " + sim.siguiente_gesto()
                    print("[PC]", mensaje)

                vj = V_JUNTA * dt
                if modo == 0:
                    sim.caminar(jy, -jx, dt)
                else:
                    sim.caminar(0.0, 0.0, dt)          # frena suave al salir del modo
                    if modo == 1:
                        sim.mover_brazo("der", d_elev=jy * vj, d_adel=jx * vj)
                    elif modo == 2:
                        sim.mover_brazo("der", d_codo=jy * vj, d_giro=jx * vj)
                    elif modo == 3:
                        sim.mover_brazo("izq", d_elev=jy * vj, d_adel=-jx * vj)
                    elif modo == 4:
                        sim.mover_brazo("izq", d_codo=jy * vj, d_giro=-jx * vj)
                    elif modo == 5:
                        sim.mover_torso(-jx * vj, -jy * vj)
                    elif modo == 6:
                        sim.mover_postura(-jy * V_AGACHAR * dt, jx * vj * 0.5)
                sim.actualizar(dt)

                if gui:
                    if k % 3 == 0:
                        sim.seguir_con_camara()
                    if k % 10 == 0:
                        sim.camara_cabeza()
                    if k % 8 == 0:
                        sim.mostrar(modo, vivo, mensaje)
                elif k % 60 == 0:
                    print("t=%5.1f modo=%d pos=(%.2f, %.2f, %.2f) giro=%.2f v=%.2f piso=%.2f %s" % (
                        i * DT_SIM, modo, sim.x, sim.y, sim.z, sim.yaw, sim.v, sim.piso,
                        "OBSTACULO" if sim.bloqueado else ""))
            p.stepSimulation()
            atraso = (i + 1) * DT_SIM - (time.time() - t_ini)
            if atraso > 0:
                time.sleep(atraso)
    except KeyboardInterrupt:
        pass
    finally:
        entrada.cerrar()
        p.disconnect()


if __name__ == "__main__":
    main()
