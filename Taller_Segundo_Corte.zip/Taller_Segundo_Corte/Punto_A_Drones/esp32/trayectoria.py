# trayectoria.py
# Planificador de trayectoria de los drones (A -> B -> C).
# Este archivo corre DENTRO de la ESP32-S3 (MicroPython), pero esta escrito en
# Python puro, asi que el PC tambien lo puede importar para probar sin la placa.
#
# La ESP32 decide hacia que punto se va, genera una trayectoria suave (perfil
# de quinto orden) y envia al PC el punto de referencia (setpoint) 50 veces por
# segundo. El PC solo ejecuta el control PID de cada dron para seguir ese punto.

import math

# Puntos de la mision (nombre, x, y, z) en metros, en el mundo de PyBullet
PUNTOS = (
    ("A", 0.0, 0.0, 0.6),
    ("B", 1.2, 0.8, 1.0),
    ("C", -1.0, 1.0, 0.7),
)

ALTURA_INICIAL = 0.1   # los drones arrancan en el piso, debajo del punto A
V_MAX = 0.35           # velocidad maxima de la formacion (m/s)
T_MIN = 2.5            # duracion minima de un tramo (s)
ESPERA = 3.0           # tiempo que la formacion se queda en cada punto en modo AUTO (s)
V_JOYSTICK = 0.30      # velocidad del ajuste manual con el joystick (m/s)
AJUSTE_MAX = 0.6       # ajuste manual maximo alrededor del punto (m)


def _limitar(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


def _suave(s):
    # Perfil de quinto orden: arranca y frena con velocidad y aceleracion cero
    return s * s * s * (10.0 - 15.0 * s + 6.0 * s * s)


class Planificador:
    def __init__(self):
        _, x, y, _ = PUNTOS[0]
        self.ref = [x, y, ALTURA_INICIAL]   # referencia actual (sin ajuste manual)
        self.ajuste = [0.0, 0.0]            # ajuste manual del joystick (x, y)
        self.auto = True                    # modo AUTO: recorre A -> B -> C solo
        self.estado = "DESPEGUE"
        self._nuevo_tramo(0, despegue=True)

    # ---------------- comandos que llegan desde los botones ----------------
    def siguiente(self):
        """Pulsacion corta: modo MANUAL, ir al siguiente punto (A->B->C->A)."""
        self.auto = False
        self._nuevo_tramo((self.destino + 1) % len(PUNTOS))

    def iniciar_auto(self):
        """Pulsacion larga: reinicia la mision automatica desde A."""
        self.auto = True
        self._nuevo_tramo(0)

    # ---------------- logica interna ----------------
    def _nuevo_tramo(self, idx, despegue=False):
        # El tramo nuevo arranca donde esta la formacion (incluido el ajuste),
        # asi la referencia nunca salta.
        self.ref[0] += self.ajuste[0]
        self.ref[1] += self.ajuste[1]
        self.ajuste = [0.0, 0.0]
        self.inicio = list(self.ref)
        self.destino = idx
        _, x, y, z = PUNTOS[idx]
        self.fin = [x, y, z]
        d = math.sqrt(sum((self.fin[i] - self.inicio[i]) ** 2 for i in range(3)))
        # 1.875 * d / v es la duracion con la que el perfil de 5o orden llega a v_max
        self.duracion = max(T_MIN, 1.875 * d / V_MAX)
        self.t = 0.0
        self.espera = 0.0
        self.llego = False
        if not despegue:
            self.estado = "HACIA_" + PUNTOS[idx][0]

    def actualizar(self, dt, jx, jy):
        """Avanza el planificador dt segundos.
        jx, jy: joystick normalizado entre -1 y 1.
        Devuelve (x, y, z) de la referencia de la formacion."""
        if not self.llego:
            self.t += dt
            s = _suave(_limitar(self.t / self.duracion, 0.0, 1.0))
            for i in range(3):
                self.ref[i] = self.inicio[i] + (self.fin[i] - self.inicio[i]) * s
            if self.t >= self.duracion:
                self.llego = True
                self.estado = "EN_" + PUNTOS[self.destino][0]
        else:
            # Ajuste manual fino con el joystick mientras se esta en el punto
            self.ajuste[0] = _limitar(self.ajuste[0] + jx * V_JOYSTICK * dt, -AJUSTE_MAX, AJUSTE_MAX)
            self.ajuste[1] = _limitar(self.ajuste[1] + jy * V_JOYSTICK * dt, -AJUSTE_MAX, AJUSTE_MAX)
            if self.auto:
                if self.destino < len(PUNTOS) - 1:
                    self.espera += dt
                    if self.espera >= ESPERA:
                        self._nuevo_tramo(self.destino + 1)
                else:
                    self.auto = False
                    self.estado = "FIN_MISION"

        return (self.ref[0] + self.ajuste[0], self.ref[1] + self.ajuste[1], self.ref[2])

    def modo(self):
        return "AUTO" if self.auto else "MANUAL"

    def nombre_destino(self):
        return PUNTOS[self.destino][0]
