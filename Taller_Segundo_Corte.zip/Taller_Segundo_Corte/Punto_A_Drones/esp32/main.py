# main.py  -  ESP32-S3 (MicroPython)
# Punto A: control de la mision de los drones (A -> B -> C) desde la ESP32-S3.
#
# Hardware: joystick analogico KY-023
#   VRx -> GPIO1   VRy -> GPIO2   SW -> GPIO4   +5V -> 3V3   GND -> GND
#
# Controles:
#   - Pulsacion LARGA (>0.7 s) del joystick: inicia la mision AUTO A -> B -> C
#   - Pulsacion CORTA: modo MANUAL, salta al siguiente punto (A -> B -> C -> A)
#   - Mover el joystick (cuando la formacion esta en un punto): ajuste fino en X/Y
#
# Mensajes que se envian por USB al PC (50 por segundo):
#   SP,<x>,<y>,<z>,<destino>,<estado>,<modo>
#   WP,<nombre>,<x>,<y>,<z>        (cada segundo, definicion de los puntos)

import sys
import time
from machine import Pin, ADC
from trayectoria import Planificador, PUNTOS

# ---------------- configuracion de pines ----------------
PIN_VRX = 1
PIN_VRY = 2
PIN_SW = 4

INVERTIR_X = False   # cambiar a True si el eje X sale al reves
INVERTIR_Y = True    # en el KY-023, empujar hacia adelante suele dar un valor menor
INTERCAMBIAR_XY = False

PERIODO_MS = 20          # 50 Hz
PRESION_LARGA_MS = 700
ZONA_MUERTA = 0.12
FILTRO = 0.35            # 0 = muy suave, 1 = sin filtro


class Joystick:
    def __init__(self, pin_x, pin_y):
        self.ax = ADC(Pin(pin_x))
        self.ay = ADC(Pin(pin_y))
        self.ax.atten(ADC.ATTN_11DB)   # rango de lectura 0 - 3.3 V
        self.ay.atten(ADC.ATTN_11DB)
        self.fx = 0.0
        self.fy = 0.0
        self.calibrar()

    def calibrar(self, n=64):
        # Al arrancar el joystick debe estar suelto (en el centro)
        sx = sy = 0
        for _ in range(n):
            sx += self.ax.read_u16()
            sy += self.ay.read_u16()
            time.sleep_ms(2)
        self.cx = sx / n
        self.cy = sy / n

    @staticmethod
    def _normalizar(v, c):
        r = (v - c) / (65535 - c) if v >= c else (v - c) / c
        r = max(-1.0, min(1.0, r))
        if abs(r) < ZONA_MUERTA:
            return 0.0
        signo = 1.0 if r > 0 else -1.0
        r = (abs(r) - ZONA_MUERTA) / (1.0 - ZONA_MUERTA)
        # curva "expo": mas precision cerca del centro
        return signo * (0.4 * r + 0.6 * r * r * r)

    def leer(self):
        nx = self._normalizar(self.ax.read_u16(), self.cx)
        ny = self._normalizar(self.ay.read_u16(), self.cy)
        if INTERCAMBIAR_XY:
            nx, ny = ny, nx
        if INVERTIR_X:
            nx = -nx
        if INVERTIR_Y:
            ny = -ny
        self.fx += FILTRO * (nx - self.fx)
        self.fy += FILTRO * (ny - self.fy)
        if abs(self.fx) < 0.01:
            self.fx = 0.0
        if abs(self.fy) < 0.01:
            self.fy = 0.0
        return self.fx, self.fy


class Boton:
    """Distingue pulsacion corta y larga del pulsador del joystick."""
    def __init__(self, pin):
        self.p = Pin(pin, Pin.IN, Pin.PULL_UP)
        self.antes = False
        self.t0 = 0
        self.larga_hecha = False

    def evento(self):
        ahora = time.ticks_ms()
        presionado = self.p.value() == 0
        ev = None
        if presionado and not self.antes:
            self.t0 = ahora
            self.larga_hecha = False
        elif presionado and not self.larga_hecha:
            if time.ticks_diff(ahora, self.t0) >= PRESION_LARGA_MS:
                self.larga_hecha = True
                ev = "LARGA"
        elif not presionado and self.antes:
            if not self.larga_hecha and time.ticks_diff(ahora, self.t0) > 30:
                ev = "CORTA"
        self.antes = presionado
        return ev


def enviar_puntos():
    for nombre, x, y, z in PUNTOS:
        sys.stdout.write("WP,%s,%.3f,%.3f,%.3f\n" % (nombre, x, y, z))


def main():
    joy = Joystick(PIN_VRX, PIN_VRY)
    boton = Boton(PIN_SW)
    plan = Planificador()
    sys.stdout.write("INFO,ESP32-S3 drones lista\n")
    enviar_puntos()

    t_prev = time.ticks_ms()
    t_wp = t_prev
    while True:
        t_ini = time.ticks_ms()
        dt = time.ticks_diff(t_ini, t_prev) / 1000.0
        t_prev = t_ini

        ev = boton.evento()
        if ev == "CORTA":
            plan.siguiente()
        elif ev == "LARGA":
            plan.iniciar_auto()

        jx, jy = joy.leer()
        x, y, z = plan.actualizar(dt, jx, jy)
        sys.stdout.write("SP,%.3f,%.3f,%.3f,%s,%s,%s\n" % (
            x, y, z, plan.nombre_destino(), plan.estado, plan.modo()))

        if time.ticks_diff(t_ini, t_wp) >= 1000:
            t_wp = t_ini
            enviar_puntos()

        espera = PERIODO_MS - time.ticks_diff(time.ticks_ms(), t_ini)
        if espera > 0:
            time.sleep_ms(espera)


main()
