"""
drones_esp32.py  -  Punto A (real-to-sim)

Mueve una formacion de drones de un punto A a un punto B y a un punto C en
gym-pybullet-drones. La mision la gestiona la ESP32-S3: ella decide el destino,
genera la trayectoria suave y envia la referencia (setpoint) por USB.
El PC solo:
  1. Lee la referencia que manda la ESP32-S3.
  2. Calcula el control PID (DSLPIDControl) de cada dron para seguirla.
  3. Simula la fisica en PyBullet y dibuja los puntos A, B, C y la ruta.

Uso:
  python drones_esp32.py --puerto COM7
  python drones_esp32.py --sin-esp          (prueba con el teclado, sin la placa)

Teclas en modo --sin-esp (con la ventana de PyBullet activa):
  flechas = joystick,  n = pulsacion corta,  m = pulsacion larga
"""

import argparse
import os
import sys
import threading
import time

import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))


# ---------------------------------------------------------------------------
# Ubicar el repositorio gym-pybullet-drones (no hace falta instalarlo con pip)
# ---------------------------------------------------------------------------
def preparar_repo(ruta):
    candidatas = [ruta] if ruta else [
        os.path.join(AQUI, "gym-pybullet-drones"),
        os.path.join(AQUI, "..", "gym-pybullet-drones"),
        os.path.join(AQUI, "..", "..", "gym-pybullet-drones"),
    ]
    for c in candidatas:
        if c and os.path.isdir(os.path.join(c, "gym_pybullet_drones")):
            sys.path.insert(0, os.path.abspath(c))
            return
    # Si no se encuentra la carpeta, se intenta usar el paquete instalado con pip


# ---------------------------------------------------------------------------
# Lectura del puerto serie en un hilo aparte (para no frenar la simulacion)
# ---------------------------------------------------------------------------
class LectorSerial(threading.Thread):
    def __init__(self, puerto, baud=115200):
        super().__init__(daemon=True)
        import serial
        self.serial = serial
        self.ser = serial.Serial(puerto, baud, timeout=0.1)
        self.lock = threading.Lock()
        self.sp = None          # (x, y, z, destino, estado, modo)
        self.t_sp = 0.0
        self.puntos = {}        # nombre -> (x, y, z)
        self.activo = True

    def run(self):
        while self.activo:
            try:
                linea = self.ser.readline().decode("utf-8", errors="ignore").strip()
            except Exception:
                if self.activo:
                    print("[PC] Se perdio la conexion con la ESP32-S3")
                break
            if not linea:
                continue
            partes = linea.split(",")
            try:
                if partes[0] == "SP" and len(partes) >= 7:
                    dato = (float(partes[1]), float(partes[2]), float(partes[3]),
                            partes[4], partes[5], partes[6])
                    with self.lock:
                        self.sp = dato
                        self.t_sp = time.time()
                elif partes[0] == "WP" and len(partes) >= 5:
                    with self.lock:
                        self.puntos[partes[1]] = (float(partes[2]), float(partes[3]), float(partes[4]))
                elif partes[0] == "INFO":
                    print("[ESP32]", linea[5:])
            except ValueError:
                pass  # linea incompleta: se ignora

    def leer(self):
        with self.lock:
            return self.sp, self.t_sp, dict(self.puntos)

    def cerrar(self):
        self.activo = False
        try:
            self.ser.close()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Fuente "sin ESP": usa el MISMO planificador de la ESP32 (esp32/trayectoria.py)
# y el teclado de PyBullet como joystick.
# ---------------------------------------------------------------------------
class FuenteTeclado:
    def __init__(self, p, cliente):
        sys.path.insert(0, os.path.join(AQUI, "..", "esp32"))
        import trayectoria
        self.p = p
        self.cliente = cliente
        self.plan = trayectoria.Planificador()
        self.puntos = {n: (x, y, z) for n, x, y, z in trayectoria.PUNTOS}
        self.sp = None

    def actualizar(self, dt, usar_teclado=True):
        p = self.p
        jx = jy = 0.0
        if usar_teclado:
            teclas = p.getKeyboardEvents(physicsClientId=self.cliente)
            if teclas.get(p.B3G_LEFT_ARROW, 0) & p.KEY_IS_DOWN:
                jx -= 1
            if teclas.get(p.B3G_RIGHT_ARROW, 0) & p.KEY_IS_DOWN:
                jx += 1
            if teclas.get(p.B3G_UP_ARROW, 0) & p.KEY_IS_DOWN:
                jy += 1
            if teclas.get(p.B3G_DOWN_ARROW, 0) & p.KEY_IS_DOWN:
                jy -= 1
            if teclas.get(ord("n"), 0) & p.KEY_WAS_TRIGGERED:
                self.plan.siguiente()
            if teclas.get(ord("m"), 0) & p.KEY_WAS_TRIGGERED:
                self.plan.iniciar_auto()
        x, y, z = self.plan.actualizar(dt, jx, jy)
        self.sp = (x, y, z, self.plan.nombre_destino(), self.plan.estado, self.plan.modo())

    def leer(self):
        return self.sp, time.time(), self.puntos


# ---------------------------------------------------------------------------
# Programa principal
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="Drones A -> B -> C controlados desde la ESP32-S3")
    ap.add_argument("--puerto", default="COM7", help="Puerto COM de la ESP32-S3")
    ap.add_argument("--sin-esp", action="store_true", help="Probar sin la placa (teclado)")
    ap.add_argument("--drones", type=int, default=3, help="Cantidad de drones (1 a 6)")
    ap.add_argument("--repo", default=None, help="Ruta a la carpeta gym-pybullet-drones")
    ap.add_argument("--duracion", type=float, default=0, help="Segundos de simulacion (0 = sin limite)")
    ap.add_argument("--sin-gui", action="store_true", help="Sin ventana (solo para pruebas)")
    args = ap.parse_args()

    preparar_repo(args.repo)
    import pybullet as p
    from gym_pybullet_drones.envs.CtrlAviary import CtrlAviary
    from gym_pybullet_drones.control.DSLPIDControl import DSLPIDControl
    from gym_pybullet_drones.utils.enums import DroneModel, Physics
    from gym_pybullet_drones.utils.utils import sync

    gui = not args.sin_gui
    n = max(1, min(6, args.drones))

    # ---- fuente de la referencia: ESP32-S3 o teclado ----
    lector = None
    if not args.sin_esp:
        lector = LectorSerial(args.puerto)
        lector.start()
        print("[PC] Esperando datos de la ESP32-S3 en", args.puerto, "...")
        t0 = time.time()
        while lector.leer()[0] is None and time.time() - t0 < 5:
            time.sleep(0.05)
        if lector.leer()[0] is None:
            print("[PC] No llegan datos. Revisa el puerto, cierra otras consolas o reinicia la placa.")

    # ---- formacion: drones repartidos en un circulo alrededor de la referencia ----
    radio = 0.3 if n > 1 else 0.0
    OFFSETS = np.array([[radio * np.cos(2 * np.pi * i / n + np.pi / 2),
                         radio * np.sin(2 * np.pi * i / n + np.pi / 2), 0.0] for i in range(n)])
    inicio = np.array([0.0, 0.0, 0.1])
    if lector and lector.leer()[0] is not None:
        sp = lector.leer()[0]
        inicio = np.array([sp[0], sp[1], 0.1])
    INIT_XYZS = inicio + OFFSETS
    INIT_RPYS = np.zeros((n, 3))

    env = CtrlAviary(drone_model=DroneModel.CF2X,
                     num_drones=n,
                     initial_xyzs=INIT_XYZS,
                     initial_rpys=INIT_RPYS,
                     physics=Physics.PYB,
                     neighbourhood_radius=10,
                     pyb_freq=240,
                     ctrl_freq=48,
                     gui=gui,
                     record=False,
                     obstacles=True,
                     user_debug_gui=False)
    cliente = env.getPyBulletClient()
    obs, info = env.reset()   # se reinicia ANTES de dibujar (reset borra el mundo)
    ctrl = [DSLPIDControl(drone_model=DroneModel.CF2X) for _ in range(n)]

    teclado = None
    if args.sin_esp:
        teclado = FuenteTeclado(p, cliente)

    if gui:
        p.resetDebugVisualizerCamera(cameraDistance=3.2, cameraYaw=-35, cameraPitch=-30,
                                     cameraTargetPosition=[0.1, 0.6, 0.4],
                                     physicsClientId=cliente)

    # ---- elementos visuales: puntos A, B, C, referencia y estela ----
    colores = {"A": [1, 0.2, 0.2, 0.8], "B": [0.2, 0.8, 0.2, 0.8], "C": [0.2, 0.4, 1, 0.8]}
    marcas = {}

    def dibujar_puntos(puntos):
        for nombre, pos in puntos.items():
            if nombre in marcas and np.allclose(marcas[nombre][1], pos):
                continue
            if nombre in marcas:
                p.removeBody(marcas[nombre][0], physicsClientId=cliente)
                p.removeUserDebugItem(marcas[nombre][2], physicsClientId=cliente)
            forma = p.createVisualShape(p.GEOM_SPHERE, radius=0.06,
                                        rgbaColor=colores.get(nombre, [1, 1, 0, 0.8]),
                                        physicsClientId=cliente)
            cuerpo = p.createMultiBody(baseMass=0, baseVisualShapeIndex=forma,
                                       basePosition=pos, physicsClientId=cliente)
            texto = p.addUserDebugText("Punto " + nombre, [pos[0], pos[1], pos[2] + 0.15],
                                       textColorRGB=colores.get(nombre, [1, 1, 0])[:3],
                                       textSize=1.4, physicsClientId=cliente)
            marcas[nombre] = (cuerpo, pos, texto)

    forma_ref = p.createVisualShape(p.GEOM_SPHERE, radius=0.035, rgbaColor=[1, 0.8, 0, 1],
                                    physicsClientId=cliente)
    marca_ref = p.createMultiBody(baseMass=0, baseVisualShapeIndex=forma_ref,
                                  basePosition=inicio.tolist(), physicsClientId=cliente)
    hud = -1
    ultimo_centro = None

    # ---- bucle de control ----
    action = np.zeros((n, 4))
    referencia = inicio.copy()
    estado_txt = "ESPERANDO ESP32"
    pasos = int(args.duracion * env.CTRL_FREQ) if args.duracion > 0 else 10 ** 12
    START = time.time()
    try:
        for i in range(pasos):
            # 1) Referencia desde la ESP32-S3 (o el teclado)
            if teclado:
                teclado.actualizar(env.CTRL_TIMESTEP, usar_teclado=gui)
                sp, t_sp, puntos = teclado.leer()
            else:
                sp, t_sp, puntos = lector.leer()
            if sp is not None and time.time() - t_sp < 1.0:
                referencia = np.array(sp[:3])
                estado_txt = "%s | %s | destino %s" % (sp[5], sp[4], sp[3])
            elif sp is not None:
                estado_txt = "SIN SENAL DE LA ESP32: manteniendo posicion"

            # 2) Control PID de cada dron hacia su lugar en la formacion
            for j in range(n):
                action[j, :], _, _ = ctrl[j].computeControlFromState(
                    control_timestep=env.CTRL_TIMESTEP,
                    state=obs[j],
                    target_pos=referencia + OFFSETS[j],
                    target_rpy=INIT_RPYS[j, :])

            # 3) Paso de simulacion
            obs, reward, terminated, truncated, info = env.step(action)

            # 4) Dibujos (cada 4 pasos para no cargar la simulacion)
            if i % 4 == 0:
                if puntos:
                    dibujar_puntos(puntos)
                p.resetBasePositionAndOrientation(marca_ref, referencia.tolist(), [0, 0, 0, 1],
                                                  physicsClientId=cliente)
                centro = np.mean([obs[j][0:3] for j in range(n)], axis=0)
                if ultimo_centro is not None and np.linalg.norm(centro - ultimo_centro) > 0.02:
                    p.addUserDebugLine(ultimo_centro.tolist(), centro.tolist(), [1, 0.5, 0], 2,
                                       physicsClientId=cliente)
                    ultimo_centro = centro
                elif ultimo_centro is None:
                    ultimo_centro = centro
                if gui and i % 12 == 0:
                    hud = p.addUserDebugText(estado_txt, [-1.6, -0.6, 1.6], textColorRGB=[0, 0, 0],
                                             textSize=1.2, replaceItemUniqueId=hud,
                                             physicsClientId=cliente)
            if not gui and i % 48 == 0:
                centro = np.mean([obs[j][0:3] for j in range(n)], axis=0)
                print("t=%5.1fs  ref=%s  centro=%s  %s" % (
                    i / env.CTRL_FREQ, np.round(referencia, 2), np.round(centro, 2), estado_txt))

            # Tiempo real: la ESP32 genera la trayectoria con su propio reloj
            sync(i, START, env.CTRL_TIMESTEP)
    except KeyboardInterrupt:
        pass
    finally:
        if lector:
            lector.cerrar()
        env.close()


if __name__ == "__main__":
    main()
